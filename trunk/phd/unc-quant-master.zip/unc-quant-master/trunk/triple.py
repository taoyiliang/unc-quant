
def run(x,y,z):
  return .5**3*(1.-x)*(1.-y)*(1.-z)

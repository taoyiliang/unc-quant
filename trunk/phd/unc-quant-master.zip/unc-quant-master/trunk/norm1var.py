import numpy as np

def run(x):
  return np.exp(-x*x)

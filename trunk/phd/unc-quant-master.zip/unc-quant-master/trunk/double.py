
def run(x,y):
  return (7.-x)*(20.-2*y)

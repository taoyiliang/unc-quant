
def run(x):
  return 2.*x+1.
  #return x*x-x+1.

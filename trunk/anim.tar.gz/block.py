import matplotlib.pyplot as plt
import matplotlib.patches as patches

fin = file('index_hist.out','r')

def plotSet(ax,pts):
  next = pts[-1]
  for pt in pts[:-1]:
    ax.add_patch(patches.Rectangle(pt,1,1,color='blue'))
  ax.add_patch(patches.Circle((next[0]+0.5,next[1]+0.5),0.4,color='green'))
  ax.set_xticks(range(1,5))
  ax.set_yticks(range(1,5))
  plt.axis([0,5,0,5])
  lw = 3
  plt.plot([1,1],[0,5],'k-',linewidth=lw)
  plt.plot([2,2],[0,5],'k-',linewidth=lw)
  plt.plot([3,3],[0,5],'k-',linewidth=lw)
  plt.plot([4,4],[0,5],'k-',linewidth=lw)
  plt.plot([0,5],[1,1],'k-',linewidth=lw)
  plt.plot([0,5],[2,2],'k-',linewidth=lw)
  plt.plot([0,5],[3,3],'k-',linewidth=lw)
  plt.plot([0,5],[4,4],'k-',linewidth=lw)

pts = []
for l,line in enumerate(fin):
  if l==0:continue
  pt = line.split('|')[-1].strip('() \n').split(',')
  for i,p in enumerate(pt): pt[i] = int(p)
  pts.append(pt)

fig = plt.figure()#figsize=(12,6))

ax7 = plt.subplot(337)#,aspect='equal')
plotSet(ax7,pts[:10])
plt.title('Step 9')
plt.xlabel('Polynomials in $y_1$')
plt.ylabel('Polynomials in $y_2$')

ax8 = plt.subplot(338,sharey=ax7)#,aspect='equal')
plotSet(ax8,pts[:11])
plt.title('Step 10')
plt.xlabel('Polynomials in $y_1$')
plt.setp(ax8.get_yticklabels(),visible=False)

ax9 = plt.subplot(339,sharey=ax7)#,aspect='equal')
plotSet(ax9,pts[:12])
plt.title('Step 11')
plt.xlabel('Polynomials in $y_1$')
plt.setp(ax9.get_yticklabels(),visible=False)

ax1 = plt.subplot(331,sharex=ax7)#,aspect='equal')
plotSet(ax1,pts[:4])
plt.title('Step 3')
plt.ylabel('Polynomials in $y_2$')
plt.setp(ax1.get_xticklabels(),visible=False)
#plt.xlabel('Polynomials in $y_1$')
#plt.ylabel('Polynomials in $y_2$')

ax2 = plt.subplot(332,sharey=ax1,sharex=ax8)#,aspect='equal')
plotSet(ax2,pts[:5])
plt.title('Step 4')
plt.setp(ax2.get_yticklabels(),visible=False)
plt.setp(ax2.get_xticklabels(),visible=False)

ax3 = plt.subplot(333,sharey=ax1,sharex=ax9)#,aspect='equal')
plotSet(ax3,pts[:6])
plt.title('Step 5')
plt.setp(ax3.get_yticklabels(),visible=False)
plt.setp(ax3.get_xticklabels(),visible=False)

ax4 = plt.subplot(334,sharex=ax7)#,aspect='equal')
plotSet(ax4,pts[:7])
plt.title('Step 6')
plt.ylabel('Polynomials in $y_2$')
plt.setp(ax4.get_xticklabels(),visible=False)

ax5 = plt.subplot(335,sharey=ax4,sharex=ax8)#,aspect='equal')
plotSet(ax5,pts[:8])
plt.title('Step 7')
plt.setp(ax5.get_yticklabels(),visible=False)
plt.setp(ax5.get_xticklabels(),visible=False)

ax6 = plt.subplot(336,sharey=ax4,sharex=ax9)#,aspect='equal')
plotSet(ax6,pts[:9])
plt.title('Step 8')
plt.setp(ax6.get_yticklabels(),visible=False)
plt.setp(ax6.get_xticklabels(),visible=False)


plt.savefig('asc_block.pdf')

plt.show()

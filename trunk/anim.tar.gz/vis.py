import matplotlib.pyplot as plt
import matplotlib.patches as patches

fin = file('index_hist.out','r')

def plotSet(ax,pts,next):
  for pt in pts:
    ax.add_patch(patches.Rectangle(pt,1,1,color='blue'))
  ax.add_patch(patches.Circle((next[0]+0.5,next[1]+0.5),0.4,color='green'))
  ax.set_xticks(range(5))
  ax.set_yticks(range(5))
  plt.axis([0,5,0,5])
  lw = 3
  plt.plot([1,1],[0,5],'k-',linewidth=lw)
  plt.plot([2,2],[0,5],'k-',linewidth=lw)
  plt.plot([3,3],[0,5],'k-',linewidth=lw)
  plt.plot([4,4],[0,5],'k-',linewidth=lw)
  plt.plot([0,5],[1,1],'k-',linewidth=lw)
  plt.plot([0,5],[2,2],'k-',linewidth=lw)
  plt.plot([0,5],[3,3],'k-',linewidth=lw)
  plt.plot([0,5],[4,4],'k-',linewidth=lw)

pts = []
for l,line in enumerate(fin):
  if l==0:continue
  pt = line.split('|')[-1].strip('() \n').split(',')
  for i,p in enumerate(pt): pt[i] = int(p)
  pts.append(pt)

fig = plt.figure(figsize=(12,6))
#ax1 = fig.add_subplot(121)#,aspect='equal')
ax1 = plt.subplot(121)#,aspect='equal')
plotSet(ax1,pts[:6],pts[6])
plt.title('Adaptive Index Set, Step 6')
plt.xlabel('Polynomials in $y_1$')
plt.ylabel('Polynomials in $y_2$')

ax = plt.subplot(122,sharey=ax1)#,aspect='equal')
plotSet(ax,pts[:7],pts[7])
plt.title('Adaptive Index Set, Step 7')
plt.xlabel('Polynomials in $y_1$')
plt.setp(ax.get_yticklabels(),visible=False)

#ax = fig.add_subplot(133,aspect='equal')
#plotSet(ax,pts[:8],pts[8])
#plt.title('Adaptive Index Set, Step 8')

print 'h,w:',fig.get_figheight(),fig.get_figwidth()

plt.savefig('asc_step.pdf')

plt.show()

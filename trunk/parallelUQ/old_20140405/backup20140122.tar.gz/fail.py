
for x in notexist:
  print x
